"""
admin.py - Registro de modelos en el panel de administración de Django.
Permite gestionar entidades desde la interfaz administrativa.
"""
from django.contrib import admin
from .models import Sucursal, Libro, Ejemplar, Usuario, Prestamo, Reserva, Multa

admin.site.register(Sucursal)
admin.site.register(Libro)
admin.site.register(Ejemplar)
admin.site.register(Usuario)
admin.site.register(Prestamo)
admin.site.register(Reserva)
admin.site.register(Multa)
