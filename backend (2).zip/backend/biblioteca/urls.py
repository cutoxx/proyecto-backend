"""
urls.py - Define las rutas principales de la API REST de la biblioteca.
Incluye rutas para ViewSets, autenticación y endpoints personalizados.
"""
from django.urls import path
from . import views
from rest_framework.routers import DefaultRouter
from .views import SucursalViewSet, LibroViewSet, EjemplarViewSet, UsuarioViewSet, PrestamoViewSet, ReservaViewSet, MultaViewSet
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

router = DefaultRouter()
router.register(r'sucursales', SucursalViewSet)
router.register(r'libros', LibroViewSet)
router.register(r'ejemplares', EjemplarViewSet)
router.register(r'usuarios', UsuarioViewSet)
router.register(r'prestamos', PrestamoViewSet)
router.register(r'reservas', ReservaViewSet)
router.register(r'multas', MultaViewSet)

urlpatterns = router.urls + [
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('prestamos/crear/', views.crear_prestamo, name='crear_prestamo'),
    path('usuarios/perfil/', views.usuario_perfil, name='usuario_perfil'),
    path('usuarios/historial-prestamos/', views.usuario_historial_prestamos, name='usuario_historial_prestamos'),
    path('usuarios/mis-reservas/', views.usuario_mis_reservas, name='usuario_mis_reservas'),
    path('sucursales/<int:sucursal_id>/inventario/', views.sucursal_inventario, name='sucursal_inventario'),
    path('libros/buscar/', views.libro_buscar, name='libro_buscar'),
    path('reportes/populares/', views.reportes_populares, name='reportes_populares'),
    path('reportes/morosidad/', views.reportes_morosidad, name='reportes_morosidad'),
    path('reportes/estadisticas-sucursal/', views.reportes_estadisticas_sucursal, name='reportes_estadisticas_sucursal'),
] 