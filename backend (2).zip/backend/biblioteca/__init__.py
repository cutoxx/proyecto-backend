"""
__init__.py - Inicialización del paquete de la app biblioteca.
Configura PyMySQL como backend de MySQL para Django.
"""
import pymysql
pymysql.install_as_MySQLdb()
