"""
models.py - Modelos principales del sistema de gestión de biblioteca.
Define las entidades: Sucursal, Libro, Ejemplar, Usuario, Prestamo, Reserva, Multa.
"""
from django.db import models
from django.contrib.auth.models import AbstractUser

class Sucursal(models.Model):
    """
    Modelo que representa una sucursal de la biblioteca.
    Incluye nombre, dirección, teléfono y horario de atención.
    """
    nombre = models.CharField(max_length=100)
    direccion = models.CharField(max_length=255)
    telefono = models.CharField(max_length=20)
    horario = models.CharField(max_length=100)

    def __str__(self):
        """Retorna el nombre de la sucursal como representación de texto."""
        return self.nombre

class Libro(models.Model):
    """
    Modelo que representa un libro en la biblioteca.
    Incluye título, autor, ISBN, género, año de publicación y descripción.
    """
    titulo = models.CharField(max_length=200)
    autor = models.CharField(max_length=100)
    isbn = models.CharField(max_length=20, unique=True)
    genero = models.CharField(max_length=50)
    anio_publicacion = models.PositiveIntegerField()
    descripcion = models.TextField(blank=True)

    def __str__(self):
        """Retorna el título del libro como representación de texto."""
        return self.titulo

class Ejemplar(models.Model):
    """
    Modelo que representa un ejemplar físico de un libro en una sucursal.
    Incluye relación con libro y sucursal, código de barras y estado.
    """
    libro = models.ForeignKey(Libro, on_delete=models.CASCADE, related_name='ejemplares')
    sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE, related_name='ejemplares')
    codigo_barras = models.CharField(max_length=50, unique=True)
    ESTADO_CHOICES = [
        ('disponible', 'Disponible'),
        ('prestado', 'Prestado'),
        ('mantenimiento', 'Mantenimiento'),
    ]
    estado = models.CharField(max_length=20, choices=ESTADO_CHOICES, default='disponible')

    def __str__(self):
        """Retorna una representación de texto del ejemplar con título y código de barras."""
        return f"{self.libro.titulo} - {self.codigo_barras}"

class Usuario(AbstractUser):
    """
    Modelo personalizado de usuario para la biblioteca.
    Incluye tipo de usuario, teléfono, dirección y estado de suspensión.
    """
    TIPO_CHOICES = [
        ('regular', 'Usuario regular'),
        ('bibliotecario', 'Bibliotecario'),
        ('admin', 'Administrador'),
    ]
    tipo = models.CharField(max_length=20, choices=TIPO_CHOICES, default='regular')
    telefono = models.CharField(max_length=20, blank=True)
    direccion = models.CharField(max_length=255, blank=True)
    suspendido = models.BooleanField(default=False)

class Prestamo(models.Model):
    """
    Modelo que representa un préstamo de un ejemplar a un usuario.
    Incluye fechas, estado y posible multa asociada.
    """
    usuario = models.ForeignKey('Usuario', on_delete=models.CASCADE, related_name='prestamos')
    ejemplar = models.ForeignKey(Ejemplar, on_delete=models.CASCADE, related_name='prestamos')
    fecha_prestamo = models.DateField(auto_now_add=True)
    fecha_devolucion = models.DateField()
    estado = models.CharField(max_length=20, choices=[('activo', 'Activo'), ('devuelto', 'Devuelto'), ('vencido', 'Vencido')], default='activo')
    multa = models.DecimalField(max_digits=8, decimal_places=2, default=0)

class Reserva(models.Model):
    """
    Modelo que representa una reserva de un libro por un usuario.
    Incluye fecha, estado y posición en la cola de reservas.
    """
    usuario = models.ForeignKey('Usuario', on_delete=models.CASCADE, related_name='reservas')
    libro = models.ForeignKey(Libro, on_delete=models.CASCADE, related_name='reservas')
    fecha_reserva = models.DateField(auto_now_add=True)
    estado = models.CharField(max_length=20, choices=[('activa', 'Activa'), ('cumplida', 'Cumplida'), ('cancelada', 'Cancelada'), ('expirada', 'Expirada')], default='activa')
    posicion_cola = models.PositiveIntegerField(default=1)

class Multa(models.Model):
    """
    Modelo que representa una multa asociada a un préstamo y usuario.
    Incluye monto, fechas y estado de la multa.
    """
    usuario = models.ForeignKey('Usuario', on_delete=models.CASCADE, related_name='multas')
    prestamo = models.ForeignKey(Prestamo, on_delete=models.CASCADE, related_name='multas')
    monto = models.DecimalField(max_digits=8, decimal_places=2)
    fecha_generacion = models.DateField(auto_now_add=True)
    fecha_pago = models.DateField(null=True, blank=True)
    estado = models.CharField(max_length=20, choices=[('pendiente', 'Pendiente'), ('pagada', 'Pagada'), ('cancelada', 'Cancelada')], default='pendiente')
    descripcion = models.TextField(blank=True)
