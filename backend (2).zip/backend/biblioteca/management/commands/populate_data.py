"""
populate_data.py - Comando custom de Django para poblar la base de datos con datos de ejemplo.
Crea sucursales, libros, ejemplares, usuarios, préstamos, reservas y multas para pruebas y desarrollo.
"""
from django.core.management.base import BaseCommand
from biblioteca.models import Sucursal, Libro, Ejemplar, Usuario, Prestamo
from django.contrib.auth.hashers import make_password

class Command(BaseCommand):
    """
    Comando para poblar la base de datos con datos de ejemplo para la biblioteca.
    """
    help = 'Pobla la base de datos con datos de ejemplo'

    def handle(self, *args, **options):
        """
        Crea sucursales, libros, ejemplares y usuarios de ejemplo para pruebas y desarrollo.
        """
        self.stdout.write('Creando datos de ejemplo...')
        
        # Crear sucursales
        sucursal1 = Sucursal.objects.create(
            nombre='Biblioteca Central',
            direccion='Av. Principal 123',
            telefono='555-0101',
            horario='Lunes a Viernes 8:00-18:00'
        )
        sucursal2 = Sucursal.objects.create(
            nombre='Biblioteca Norte',
            direccion='Calle Norte 456',
            telefono='555-0202',
            horario='Lunes a Sábado 9:00-17:00'
        )
        sucursal3 = Sucursal.objects.create(
            nombre='Biblioteca Sur',
            direccion='Avenida Sur 789',
            telefono='555-0303',
            horario='Lunes a Viernes 9:00-19:00'
        ) 
        # Crear 20 libros de ejemplo
        libros = []
        for i in range(1, 21):
            libro = Libro.objects.create(
                titulo=f'Libro de Prueba {i}',
                autor=f'Autor {i}',
                isbn=f'978-84-0000-{1000+i}',
                genero='Ficción' if i % 2 == 0 else 'No Ficción',
                anio_publicacion=2000 + (i % 20),
                descripcion=f'Descripción del libro de prueba número {i}'
            )
            libros.append(libro)
        # Crear ejemplares para cada libro, distribuidos en las 3 sucursales
        sucursales = [sucursal1, sucursal2, sucursal3]
        ejemplar_count = 1
        for libro in libros:
            for sucursal in sucursales:
                # Cada libro tendrá 2 ejemplares por sucursal
                for j in range(2):
                    Ejemplar.objects.create(
                        libro=libro,
                        sucursal=sucursal,
                        codigo_barras=f'E{ejemplar_count:04d}',
                        estado='disponible' if ejemplar_count % 3 != 0 else 'mantenimiento'
                    )
                    ejemplar_count += 1
        # Crear usuarios de ejemplo (3 de cada rol)
        usuarios = []
        roles = ['regular', 'bibliotecario', 'admin']
        for rol in roles:
            for i in range(1, 4):
                usuario = Usuario.objects.create(
                    username=f'{rol}{i}',
                    email=f'{rol}{i}@email.com',
                    first_name=f'{rol.capitalize()}Nombre{i}',
                    last_name=f'{rol.capitalize()}Apellido{i}',
                    password=make_password('password123'),
                    tipo=rol,
                    telefono=f'555-0{rol[0]}{i}00',
                    direccion=f'Calle {rol.capitalize()} {i} #{i*10}'
                )
                usuarios.append(usuario)
        # Crear préstamos de ejemplo para los primeros usuarios y ejemplares
        from datetime import datetime, timedelta
        ejemplares = list(Ejemplar.objects.all())
        prestamos = []
        for i, usuario in enumerate(usuarios[:5]):
            ejemplar = ejemplares[i * 2]
            fecha_prestamo = datetime.now().date() - timedelta(days=i*2)
            fecha_devolucion = fecha_prestamo + timedelta(days=14)
            prestamo = Prestamo.objects.create(
                usuario=usuario,
                ejemplar=ejemplar,
                fecha_prestamo=fecha_prestamo,
                fecha_devolucion=fecha_devolucion,
                estado='devuelto' if i % 2 == 0 else 'activo',
                multa=0
            )
            prestamos.append(prestamo)
        # Crear reservas de ejemplo para los siguientes usuarios
        from biblioteca.models import Reserva, Multa
        for i, usuario in enumerate(usuarios[5:10]):
            Reserva.objects.create(
                usuario=usuario,
                libro=libros[i],
                fecha_reserva=datetime.now().date() - timedelta(days=i),
                estado='activa',
                posicion_cola=1
            )
        # Crear multas de ejemplo para algunos préstamos
        for i, prestamo in enumerate(prestamos[:3]):
            Multa.objects.create(
                usuario=prestamo.usuario,
                prestamo=prestamo,
                monto=1000 * (i+1),
                descripcion=f'Multa de ejemplo {i+1}'
            )
