"""
liberar_reservas.py - Comando custom de Django para liberar reservas no reclamadas en 2 días.
Expira reservas y actualiza la cola de espera automáticamente.
"""
from django.core.management.base import BaseCommand
from biblioteca.models import Reserva
from datetime import datetime, timedelta

class Command(BaseCommand):
    """
    Comando de Django para liberar (expirar) reservas que no han sido reclamadas en 2 días.
    Además, actualiza la posición de la cola de reservas para los siguientes usuarios.
    """
    help = 'Libera reservas que no han sido reclamadas en 2 días (cambia su estado a expirada y avanza la cola)'

    def handle(self, *args, **options):
        """
        Busca reservas activas con más de 2 días de antigüedad, las expira y actualiza la cola de reservas.
        """
        hoy = datetime.now().date()
        reservas_a_expirar = Reserva.objects.filter(estado='activa', fecha_reserva__lt=hoy - timedelta(days=2))
        total = reservas_a_expirar.count()
        for reserva in reservas_a_expirar:
            libro_id = reserva.libro_id
            posicion = reserva.posicion_cola
            # Expirar la reserva
            reserva.estado = 'expirada'
            reserva.save()
            # Avanzar la cola de reservas activas para ese libro
            reservas_a_avanzar = Reserva.objects.filter(
                libro_id=libro_id,
                estado='activa',
                posicion_cola__gt=posicion
            )
            for r in reservas_a_avanzar:
                r.posicion_cola -= 1
                r.save()
        self.stdout.write(self.style.SUCCESS(f'{total} reservas liberadas (expiradas) y colas actualizadas automáticamente.'))

#   python manage.py liberar_reservas

