"""
apps.py - Configuración de la app principal de la biblioteca para Django.
Define el nombre y la configuración por defecto de la app.
"""
from django.apps import AppConfig


class BibliotecaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'biblioteca'
