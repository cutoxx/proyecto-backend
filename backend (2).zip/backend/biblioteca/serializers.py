"""
serializers.py -Permiten la conversión entre modelos y representaciones JSON para la API REST.
"""
from rest_framework import serializers
from .models import Sucursal, Libro, Ejemplar, Usuario, Prestamo, Reserva, Multa

class SucursalSerializer(serializers.ModelSerializer):
    """Serializer para el modelo Sucursal."""
    class Meta:
        model = Sucursal
        fields = '__all__'

class LibroSerializer(serializers.ModelSerializer):
    """Serializer para el modelo Libro."""
    class Meta:
        model = Libro
        fields = '__all__'

class EjemplarSerializer(serializers.ModelSerializer):
    """Serializer para el modelo Ejemplar."""
    class Meta:
        model = Ejemplar
        fields = '__all__'

class UsuarioSerializer(serializers.ModelSerializer):
    """Serializer para el modelo Usuario."""
    class Meta:
        model = Usuario
        fields = '__all__'

class PrestamoSerializer(serializers.ModelSerializer):
    """Serializer para el modelo Prestamo."""
    class Meta:
        model = Prestamo
        fields = '__all__'

class ReservaSerializer(serializers.ModelSerializer):
    """Serializer para el modelo Reserva."""
    class Meta:
        model = Reserva
        fields = '__all__'

class MultaSerializer(serializers.ModelSerializer):
    """Serializer para el modelo Multa."""
    class Meta:
        model = Multa
        fields = '__all__' 