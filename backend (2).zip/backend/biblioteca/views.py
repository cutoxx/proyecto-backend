"""
views.py - Vistas y endpoints principales del sistema de gestión de biblioteca.
Incluye endpoints REST para libros, usuarios, préstamos, reservas, sucursales, multas y reportes.
Contiene lógica de negocio, validaciones y acciones personalizadas.
"""
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from .models import Libro, Usuario, Prestamo, Reserva, Sucursal, Ejemplar, Multa
from django.contrib.auth import authenticate, login, logout
from django.views.decorators.http import require_http_methods
import json
from datetime import datetime, timedelta
from rest_framework import viewsets
from .models import Sucursal, Libro, Ejemplar, Usuario, Prestamo, Reserva, Multa
from .serializers import SucursalSerializer, LibroSerializer, EjemplarSerializer, UsuarioSerializer, PrestamoSerializer, ReservaSerializer, MultaSerializer
from rest_framework.decorators import action
from django.db import models
from django.db.models import Q
from collections import Counter
from django.db.models import Count
from django.db.models import Sum



@api_view(['GET'])
def libro_list(request):
    """Lista todos los libros disponibles en la biblioteca."""
    libros = Libro.objects.all()
    data = []
    for libro in libros:
        data.append({
            'id': libro.id,
            'titulo': libro.titulo,
            'autor': libro.autor,
            'isbn': libro.isbn,
            'genero': libro.genero,
            'anio_publicacion': libro.anio_publicacion,
            'descripcion': libro.descripcion,
        })
    return Response(data)

@api_view(['GET'])
def libro_detail(request, libro_id):
    """Obtiene detalles de un libro específico, incluyendo ejemplares disponibles y totales."""
    try:
        libro = Libro.objects.get(id=libro_id)
        ejemplares = libro.ejemplares.all()
        
        data = {
            'id': libro.id,
            'titulo': libro.titulo,
            'autor': libro.autor,
            'isbn': libro.isbn,
            'genero': libro.genero,
            'anio_publicacion': libro.anio_publicacion,
            'descripcion': libro.descripcion,
            'ejemplares_disponibles': ejemplares.filter(estado='disponible').count(),
            'total_ejemplares': ejemplares.count(),
        }
        return Response(data)
    except Libro.DoesNotExist:
        return Response({'error': 'Libro no encontrado'}, status=status.HTTP_404_NOT_FOUND)

@api_view(['POST'])
def login_view(request):
    """Autentica a un usuario y retorna sus datos y tipo de usuario."""
    data = json.loads(request.body)
    username = data.get('username')
    password = data.get('password')
    
    user = authenticate(username=username, password=password)
    if user is not None:
        login(request, user)
        return Response({
            'message': 'Login exitoso',
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'tipo': user.tipo,
                'first_name': user.first_name,
                'last_name': user.last_name,
            }
        })
    else:
        return Response({'error': 'Credenciales inválidas'}, status=status.HTTP_401_UNAUTHORIZED)

@api_view(['POST'])
def logout_view(request):
    """Cierra la sesión del usuario autenticado."""
    logout(request)
    return Response({'message': 'Logout exitoso'})

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def prestamo_list(request):
    """Lista los préstamos del usuario autenticado."""
    prestamos = Prestamo.objects.filter(usuario=request.user)
    data = []
    for prestamo in prestamos:
        data.append({
            'id': prestamo.id,
            'libro': prestamo.ejemplar.libro.titulo,
            'fecha_prestamo': prestamo.fecha_prestamo,
            'fecha_devolucion': prestamo.fecha_devolucion,
            'estado': prestamo.estado,
            'multa': float(prestamo.multa),
        })
    return Response(data)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def crear_prestamo(request):
    """Crea un nuevo préstamo para el usuario autenticado si cumple las reglas de negocio."""
    data = json.loads(request.body)
    ejemplar_id = data.get('ejemplar_id')
    
    try:
        ejemplar = Ejemplar.objects.get(id=ejemplar_id, estado='disponible')
        multas_pendientes = Multa.objects.filter(usuario=request.user, estado='pendiente')
        if multas_pendientes.exists():
            return Response({'error': 'Tienes multas pendientes'}, status=status.HTTP_400_BAD_REQUEST)
        
        fecha_devolucion = datetime.now().date() + timedelta(days=14)  # 2 semanas
        prestamo = Prestamo.objects.create(
            usuario=request.user,
            ejemplar=ejemplar,
            fecha_devolucion=fecha_devolucion
        )
        
        ejemplar.estado = 'prestado'
        ejemplar.save()
        
        return Response({
            'message': 'Préstamo creado exitosamente',
            'fecha_devolucion': fecha_devolucion
        })
    except Ejemplar.DoesNotExist:
        return Response({'error': 'Ejemplar no disponible'}, status=status.HTTP_404_NOT_FOUND)

@api_view(['GET'])
def sucursal_list(request):
    """Lista todas las sucursales de la biblioteca."""
    sucursales = Sucursal.objects.all()
    data = []
    for sucursal in sucursales:
        data.append({
            'id': sucursal.id,
            'nombre': sucursal.nombre,
            'direccion': sucursal.direccion,
            'telefono': sucursal.telefono,
            'horario': sucursal.horario,
        })
    return Response(data)

@api_view(['GET'])
def home(request):
    """Vista principal del sistema de gestión de biblioteca."""
    return Response({
        'message': 'Sistema de Gestión de Biblioteca',
        'endpoints': {
            'libros': '/api/libros/',
            'login': '/api/login/',
            'prestamos': '/api/prestamos/',
            'sucursales': '/api/sucursales/',
        }
    })

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def usuario_perfil(request):
    """Devuelve el perfil del usuario autenticado."""
    user = request.user
    data = {
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'tipo': getattr(user, 'tipo', None),
        'first_name': user.first_name,
        'last_name': user.last_name,
        'telefono': getattr(user, 'telefono', ''),
        'direccion': getattr(user, 'direccion', ''),
        'suspendido': getattr(user, 'suspendido', False),
    }
    return Response(data)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def usuario_historial_prestamos(request):
    """Devuelve el historial de préstamos del usuario autenticado."""
    prestamos = Prestamo.objects.filter(usuario=request.user).select_related('ejemplar__libro')
    data = []
    for prestamo in prestamos:
        data.append({
            'id': prestamo.id,
            'libro': prestamo.ejemplar.libro.titulo,
            'fecha_prestamo': prestamo.fecha_prestamo,
            'fecha_devolucion': prestamo.fecha_devolucion,
            'estado': prestamo.estado,
            'multa': float(prestamo.multa),
        })
    return Response(data)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def usuario_mis_reservas(request):
    """Devuelve todas las reservas del usuario autenticado."""
    reservas = Reserva.objects.filter(usuario=request.user).select_related('libro')
    data = []
    for reserva in reservas:
        data.append({
            'id': reserva.id,
            'libro': reserva.libro.titulo,
            'fecha_reserva': reserva.fecha_reserva,
            'estado': reserva.estado,
            'posicion_cola': reserva.posicion_cola,
        })
    return Response(data)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def sucursal_inventario(request, sucursal_id):
    """Devuelve el inventario de ejemplares por estado para una sucursal específica."""
    from .models import Ejemplar
    try:
        sucursal = Sucursal.objects.get(id=sucursal_id)
    except Sucursal.DoesNotExist:
        return Response({'error': 'Sucursal no encontrada'}, status=status.HTTP_404_NOT_FOUND)
    ejemplares = Ejemplar.objects.filter(sucursal=sucursal)
    conteo = {
        'disponible': ejemplares.filter(estado='disponible').count(),
        'prestado': ejemplares.filter(estado='prestado').count(),
        'mantenimiento': ejemplares.filter(estado='mantenimiento').count(),
        'total': ejemplares.count(),
    }
    return Response({
        'sucursal': sucursal.nombre,
        'inventario': conteo
    })

@api_view(['GET'])
def libro_buscar(request):
    """Búsqueda avanzada de libros por título, autor, género, disponibilidad y sucursal."""
    q = request.GET.get('q', '')
    genero = request.GET.get('genero', '')
    autor = request.GET.get('autor', '')
    disponible = request.GET.get('disponible', '')
    sucursal_id = request.GET.get('sucursal', '')

    libros = Libro.objects.all()

    if q:
        libros = libros.filter(Q(titulo__icontains=q) | Q(autor__icontains=q) | Q(isbn__icontains=q))
    if genero:
        libros = libros.filter(genero__icontains=genero)
    if autor:
        libros = libros.filter(autor__icontains=autor)

    # Prefetch ejemplares para evitar N+1
    libros = libros.prefetch_related('ejemplares')

    # Filtrar por disponibilidad y sucursal
    if disponible or sucursal_id:
        libro_ids = set()
        for libro in libros:
            ejemplares = libro.ejemplares.all()
            if sucursal_id:
                ejemplares = [e for e in ejemplares if str(e.sucursal_id) == str(sucursal_id)]
            if disponible:
                if disponible == '1' or disponible.lower() == 'true':
                    ejemplares = [e for e in ejemplares if e.estado == 'disponible']
                else:
                    ejemplares = [e for e in ejemplares if e.estado != 'disponible']
            if ejemplares:
                libro_ids.add(libro.id)
        libros = libros.filter(id__in=libro_ids)

    data = []
    for libro in libros:
        data.append({
            'id': libro.id,
            'titulo': libro.titulo,
            'autor': libro.autor,
            'isbn': libro.isbn,
            'genero': libro.genero,
            'anio_publicacion': libro.anio_publicacion,
            'descripcion': libro.descripcion,
        })
    return Response(data)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def reportes_populares(request):
    """Devuelve los libros más prestados, permitiendo filtrar por rango de fechas."""
    fecha_inicio = request.GET.get('fecha_inicio')
    fecha_fin = request.GET.get('fecha_fin')
    prestamos = Prestamo.objects.all()
    if fecha_inicio:
        prestamos = prestamos.filter(fecha_prestamo__gte=fecha_inicio)
    if fecha_fin:
        prestamos = prestamos.filter(fecha_prestamo__lte=fecha_fin)
    # Anotar cantidad de préstamos por libro
    libros = Libro.objects.filter(
        ejemplares__prestamos__in=prestamos
    ).annotate(
        cantidad_prestamos=Count('ejemplares__prestamos')
    ).order_by('-cantidad_prestamos').distinct()
    data = []
    for libro in libros:
        data.append({
            'id': libro.id,
            'titulo': libro.titulo,
            'autor': libro.autor,
            'cantidad_prestamos': libro.cantidad_prestamos,
        })
    return Response(data)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def reportes_morosidad(request):
    """Devuelve usuarios con préstamos vencidos y/o multas pendientes, ordenados por morosidad."""
    usuarios = Usuario.objects.annotate(
        prestamos_vencidos=Count('prestamos', filter=models.Q(prestamos__estado='vencido')),
        monto_multas_pendientes=Sum('multas__monto', filter=models.Q(multas__estado='pendiente'))
    )
    data = []
    for usuario in usuarios:
        prestamos_vencidos = usuario.prestamos_vencidos or 0
        monto_multas = float(usuario.monto_multas_pendientes or 0)
        if prestamos_vencidos > 0 or monto_multas > 0:
            data.append({
                'id': usuario.id,
                'username': usuario.username,
                'first_name': usuario.first_name,
                'last_name': usuario.last_name,
                'prestamos_vencidos': prestamos_vencidos,
                'monto_multas_pendientes': monto_multas,
            })
    # Ordenar por monto de multas y luego por préstamos vencidos
    data.sort(key=lambda x: (x['monto_multas_pendientes'], x['prestamos_vencidos']), reverse=True)
    return Response(data)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def reportes_estadisticas_sucursal(request):
    """Devuelve estadísticas de uso por sucursal: préstamos, reservas, libros disponibles y usuarios registrados."""
    sucursales = Sucursal.objects.annotate(
        prestamos=Count('ejemplares__prestamos', distinct=True),
        reservas=Count('ejemplares__libro__reservas', distinct=True),
        libros_disponibles=Count('ejemplares', filter=Q(ejemplares__estado='disponible'), distinct=True),
        usuarios_registrados=Count('ejemplares__prestamos__usuario', distinct=True)
    )
    data = []
    for sucursal in sucursales:
        data.append({
            'id': sucursal.id,
            'nombre': sucursal.nombre,
            'prestamos': sucursal.prestamos,
            'reservas': sucursal.reservas,
            'libros_disponibles': sucursal.libros_disponibles,
            'usuarios_registrados': sucursal.usuarios_registrados,
        })
    return Response(data)

class SucursalViewSet(viewsets.ModelViewSet):
    """
    ViewSet para gestionar sucursales de la biblioteca.
    Permite operaciones CRUD sobre sucursales.
    """
    queryset = Sucursal.objects.all()
    serializer_class = SucursalSerializer
    permission_classes = [IsAuthenticated]

class LibroViewSet(viewsets.ModelViewSet):
    """
    ViewSet para gestionar libros de la biblioteca.
    Permite operaciones CRUD y validaciones de negocio al eliminar libros.
    """
    queryset = Libro.objects.all()
    serializer_class = LibroSerializer
    permission_classes = [IsAuthenticated]

    def destroy(self, request, *args, **kwargs):
        """
        Elimina un libro solo si no tiene préstamos activos.
        """
        libro = self.get_object()
        from .models import Ejemplar, Prestamo
        ejemplares = Ejemplar.objects.filter(libro=libro)
        prestamos_activos = Prestamo.objects.filter(ejemplar__in=ejemplares, estado='activo').exists()
        if prestamos_activos:
            return Response(
                {'detail': 'No se puede eliminar un libro con préstamos activos.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        return super().destroy(request, *args, **kwargs)

class EjemplarViewSet(viewsets.ModelViewSet):
    """
    ViewSet para gestionar ejemplares de libros en sucursales.
    Permite transferir ejemplares entre sucursales.
    """
    queryset = Ejemplar.objects.all()
    serializer_class = EjemplarSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=True, methods=['patch'], url_path='transferir')
    def transferir(self, request, pk=None):
        """
        Transfiere un ejemplar disponible a otra sucursal.
        """
        ejemplar = self.get_object()
        if ejemplar.estado != 'disponible':
            return Response({'detail': 'Solo se pueden transferir ejemplares disponibles.'}, status=status.HTTP_400_BAD_REQUEST)
        sucursal_id = request.data.get('sucursal')
        if not sucursal_id:
            return Response({'detail': 'Debe indicar la sucursal de destino.'}, status=status.HTTP_400_BAD_REQUEST)
        from .models import Sucursal
        try:
            sucursal_destino = Sucursal.objects.get(id=sucursal_id)
        except Sucursal.DoesNotExist:
            return Response({'detail': 'Sucursal de destino no encontrada.'}, status=status.HTTP_404_NOT_FOUND)
        ejemplar.sucursal = sucursal_destino
        ejemplar.save()
        return Response({'detail': f'El ejemplar fue transferido a la sucursal {sucursal_destino.nombre}.'})

class UsuarioViewSet(viewsets.ModelViewSet):
    """
    ViewSet para gestionar usuarios del sistema.
    Permite operaciones CRUD sobre usuarios.
    """
    queryset = Usuario.objects.all()
    serializer_class = UsuarioSerializer
    permission_classes = [IsAuthenticated]

class PrestamoViewSet(viewsets.ModelViewSet):
    """
    ViewSet para gestionar préstamos de ejemplares.
    Incluye validaciones de negocio y acción personalizada para devolver préstamos.
    """
    queryset = Prestamo.objects.all()
    serializer_class = PrestamoSerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        """
        Crea un préstamo para el usuario autenticado, validando reglas de negocio:
        - Máximo 3 préstamos activos para usuarios regulares.
        - No permitir préstamos si hay multas pendientes.
        - Duración máxima de 14 días.
        """
        usuario = request.user
        if hasattr(usuario, 'tipo') and usuario.tipo == 'regular':
            prestamos_activos = Prestamo.objects.filter(usuario=usuario, estado='activo').count()
            if prestamos_activos >= 3:
                return Response(
                    {'detail': 'No puedes tener más de 3 préstamos activos.'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            multas_pendientes = Multa.objects.filter(usuario=usuario, estado='pendiente').exists()
            if multas_pendientes:
                return Response(
                    {'detail': 'No puedes solicitar préstamos si tienes multas pendientes.'},
                    status=status.HTTP_400_BAD_REQUEST
                )
        fecha_devolucion_str = request.data.get('fecha_devolucion')
        if fecha_devolucion_str:
            try:
                fecha_devolucion = datetime.strptime(fecha_devolucion_str, '%Y-%m-%d').date()
                hoy = datetime.now().date()
                if (fecha_devolucion - hoy).days > 14:
                    return Response(
                        {'detail': 'La duración máxima de un préstamo es de 14 días.'},
                        status=status.HTTP_400_BAD_REQUEST
                    )
            except Exception:
                return Response(
                    {'detail': 'Formato de fecha de devolución inválido. Use AAAA-MM-DD.'},
                    status=status.HTTP_400_BAD_REQUEST
                )
        return super().create(request, *args, **kwargs)

    @action(detail=True, methods=['patch'], url_path='devolver')
    def devolver(self, request, pk=None):
        """
        Marca un préstamo como devuelto, libera el ejemplar y genera multa si hay retraso.
        """
        prestamo = self.get_object()
        if prestamo.estado != 'activo':
            return Response({'detail': 'El préstamo ya fue devuelto o no está activo.'}, status=status.HTTP_400_BAD_REQUEST)
        hoy = datetime.now().date()
        prestamo.estado = 'devuelto'
        prestamo.save()
        ejemplar = prestamo.ejemplar
        ejemplar.estado = 'disponible'
        ejemplar.save()
        dias_retraso = (hoy - prestamo.fecha_devolucion).days
        multa_creada = None
        if dias_retraso > 0:
            monto = dias_retraso * 1000
            multa_creada = Multa.objects.create(
                usuario=prestamo.usuario,
                prestamo=prestamo,
                monto=monto,
                descripcion=f'Retraso de {dias_retraso} día(s) en la devolución.'
            )
        if multa_creada:
            return Response({
                'detail': f'Préstamo devuelto con {dias_retraso} día(s) de retraso. Multa generada: ${monto} CLP.'
            })
        else:
            return Response({'detail': 'Préstamo devuelto a tiempo. No se generó multa.'})

class ReservaViewSet(viewsets.ModelViewSet):
    """
    ViewSet para gestionar reservas de libros.
    Incluye lógica de cola y acciones personalizadas.
    """
    queryset = Reserva.objects.all()
    serializer_class = ReservaSerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        """
        Crea una reserva para el usuario autenticado, validando reglas de negocio:
        - No permitir reservas si hay multas pendientes.
        - Asigna posición en la cola según disponibilidad.
        """
        usuario = request.user
        if hasattr(usuario, 'tipo') and usuario.tipo == 'regular':
            multas_pendientes = Multa.objects.filter(usuario=usuario, estado='pendiente').exists()
            if multas_pendientes:
                return Response(
                    {'detail': 'No puedes reservar libros si tienes multas pendientes.'},
                    status=status.HTTP_400_BAD_REQUEST
                )
        libro_id = request.data.get('libro')
        if libro_id:
            from .models import Ejemplar
            ejemplares_disponibles = Ejemplar.objects.filter(libro_id=libro_id, estado='disponible').count()
            if ejemplares_disponibles == 0:
                max_pos = Reserva.objects.filter(libro_id=libro_id, estado='activa').aggregate(models.Max('posicion_cola'))['posicion_cola__max'] or 0
                request.data['posicion_cola'] = max_pos + 1
            else:
                request.data['posicion_cola'] = 1
        return super().create(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        """
        Cancela una reserva activa y actualiza la posición de la cola para los siguientes usuarios.
        """
        reserva = self.get_object()
        if reserva.estado != 'activa':
            return Response({'detail': 'Solo se pueden cancelar reservas activas.'}, status=status.HTTP_400_BAD_REQUEST)
        libro_id = reserva.libro_id
        posicion = reserva.posicion_cola
        # Marcar como cancelada
        reserva.estado = 'cancelada'
        reserva.save()
        # Avanzar la cola de reservas activas para ese libro
        reservas_a_avanzar = Reserva.objects.filter(
            libro_id=libro_id,
            estado='activa',
            posicion_cola__gt=posicion
        )
        for r in reservas_a_avanzar:
            r.posicion_cola -= 1
            r.save()
        return Response({'detail': 'Reserva cancelada y cola actualizada.'}, status=status.HTTP_200_OK)

    @action(detail=False, methods=['get'], url_path='cola/(?P<libro_id>[^/.]+)')
    def cola_libro(self, request, libro_id=None):
        """
        Devuelve la cola de reservas activas para un libro específico, ordenada por posición y fecha.
        """
        reservas = Reserva.objects.filter(libro_id=libro_id, estado='activa').order_by('posicion_cola', 'fecha_reserva')
        data = [
            {
                'usuario': r.usuario.username,
                'fecha_reserva': r.fecha_reserva,
                'posicion_cola': r.posicion_cola
            }
            for r in reservas
        ]
        return Response(data)

class MultaViewSet(viewsets.ModelViewSet):
    """
    ViewSet para gestionar multas de usuarios.
    Actualiza la suspensión del usuario al crear o actualizar una multa.
    """
    queryset = Multa.objects.all()
    serializer_class = MultaSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        """
        Crea una multa y actualiza el estado de suspensión del usuario.
        """
        multa = serializer.save()
        self._actualizar_suspension_usuario(multa.usuario)

    def perform_update(self, serializer):
        """
        Actualiza una multa y el estado de suspensión del usuario.
        """
        multa = serializer.save()
        self._actualizar_suspension_usuario(multa.usuario)

    def _actualizar_suspension_usuario(self, usuario):
        """
        Marca al usuario como suspendido si tiene multas pendientes.
        """
        tiene_multas_pendientes = Multa.objects.filter(usuario=usuario, estado='pendiente').exists()
        usuario.suspendido = tiene_multas_pendientes
        usuario.save()
