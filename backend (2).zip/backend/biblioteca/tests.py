"""
tests.py - Pruebas automáticas para la app de biblioteca."""
from django.test import TestCase

# Create your tests here.
