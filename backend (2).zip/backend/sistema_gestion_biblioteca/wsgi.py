"""
Este archivo configura y expone la aplicación WSGI para el proyecto 'sistema_gestion_biblioteca'.

- Establece la variable de entorno 'DJANGO_SETTINGS_MODULE' para que Django utilice la configuración correcta del proyecto.
- Importa y ejecuta 'get_wsgi_application()', que inicializa la aplicación Django y la deja lista para recibir peticiones HTTP desde un servidor WSGI externo.
- La variable 'application' es el punto de entrada que utilizará el servidor web para interactuar con la aplicación Django.

este archivo permite que el proyecto 'sistema_gestion_biblioteca' sea desplegado y servido en producción a través de un servidor WSGI.
"""
import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'sistema_gestion_biblioteca.settings')

application = get_wsgi_application()
