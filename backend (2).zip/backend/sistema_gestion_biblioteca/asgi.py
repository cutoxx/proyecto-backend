"""Este archivo configura y expone la aplicación ASGI para el proyecto 'sistema_gestion_biblioteca'.

- Establece la variable de entorno 'DJANGO_SETTINGS_MODULE' para que Django utilice la configuración correcta del proyecto.
- Importa y ejecuta 'get_asgi_application()', que inicializa la aplicación Django y la deja lista para recibir peticiones asíncronas (HTTP, WebSocket, etc.) desde un servidor ASGI externo.
- La variable 'application' es el punto de entrada que utilizará el servidor ASGI para interactuar con la aplicación Django.

Este archivo permite que el proyecto 'sistema_gestion_biblioteca' sea desplegado y servido en producción a través de un servidor ASGI, habilitando soporte para aplicaciones asíncronas.
"""
import os

from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'sistema_gestion_biblioteca.settings')

application = get_asgi_application()
